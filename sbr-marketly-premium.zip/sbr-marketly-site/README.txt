SBR MARKETLY WEBSITE

Files:
- index.html
- styles.css
- script.js
- assets/logo.jpg

CONTACT:
- Email: sbr.marketly@gmail.com
- Instagram: https://www.instagram.com/sbr.marketly/

INQUIRY FORM:
The contact form uses FormSubmit to forward submitted inquiries to sbr.marketly@gmail.com.
On first deployment, FormSubmit may send a confirmation email to the receiving address. Confirm it once if requested.
The form also includes a direct Gmail compose option for visitors who prefer to email manually.

NOTES:
- Replace the _next hidden input in index.html if you later add a dedicated thank-you page.
- For production hosting, use HTTPS.
- No external JavaScript libraries are required.
