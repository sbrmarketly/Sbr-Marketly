const progress=document.getElementById('progress');
const menuToggle=document.getElementById('menuToggle');
const navLinks=document.getElementById('navLinks');
const year=document.getElementById('year');
const form=document.getElementById('inquiryForm');
const formStatus=document.getElementById('formStatus');

year.textContent=new Date().getFullYear();

window.addEventListener('scroll',()=>{
  const h=document.documentElement.scrollHeight-window.innerHeight;
  progress.style.width=(h>0?(window.scrollY/h)*100:0)+'%';
},{passive:true});

menuToggle.addEventListener('click',()=>{
  const open=navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded',open);
});
navLinks.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{
  navLinks.classList.remove('open');
  menuToggle.setAttribute('aria-expanded','false');
}));

const observer=new IntersectionObserver(entries=>entries.forEach(e=>{
  if(e.isIntersecting){e.target.classList.add('visible');observer.unobserve(e.target)}
}),{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));

// Subtle cursor interaction for desktop — disabled for touch/reduced motion.
if(window.matchMedia('(pointer:fine)').matches && !window.matchMedia('(prefers-reduced-motion:reduce)').matches){
  const art=document.querySelector('.hero-art');
  const cards=document.querySelectorAll('.service-card,.value');
  let raf;
  window.addEventListener('pointermove',e=>{
    cancelAnimationFrame(raf);
    raf=requestAnimationFrame(()=>{
      if(art){
        const r=art.getBoundingClientRect();
        const x=(e.clientX-(r.left+r.width/2))/r.width;
        const y=(e.clientY-(r.top+r.height/2))/r.height;
        if(r.bottom>0 && r.top<window.innerHeight){
          art.style.transform=`perspective(1000px) rotateY(${x*5}deg) rotateX(${y*-5}deg)`;
        }
      }
      cards.forEach(card=>{
        const r=card.getBoundingClientRect();
        card.style.setProperty('--mx',`${e.clientX-r.left}px`);
        card.style.setProperty('--my',`${e.clientY-r.top}px`);
      });
    });
  },{passive:true});
  window.addEventListener('pointerleave',()=>{if(art)art.style.transform='';});
}

// The static site uses FormSubmit for email delivery. If that service is unavailable,
// provide a Gmail compose fallback instead of leaving the visitor with a dead button.
if(form){
  form.addEventListener('submit',()=>{
    const btn=form.querySelector('.submit-btn');
    if(btn){btn.disabled=true;btn.innerHTML='Sending… <span>→</span>';}
    if(formStatus) formStatus.textContent='Opening the secure email submission…';
  });
}


// Premium header state + desktop cursor glow.
const header=document.querySelector('.site-header');
const glow=document.getElementById('cursorGlow');
const updateHeader=()=>header&&header.classList.toggle('scrolled',window.scrollY>24);
updateHeader();
window.addEventListener('scroll',updateHeader,{passive:true});

if(glow && window.matchMedia('(pointer:fine)').matches && !window.matchMedia('(prefers-reduced-motion:reduce)').matches){
  let glowRaf;
  window.addEventListener('pointermove',e=>{
    cancelAnimationFrame(glowRaf);
    glowRaf=requestAnimationFrame(()=>{
      glow.style.left=e.clientX+'px';
      glow.style.top=e.clientY+'px';
      glow.style.opacity='1';
    });
  },{passive:true});
  document.addEventListener('mouseleave',()=>glow.style.opacity='0');
}

// Magnetic micro-interaction for primary CTAs.
if(window.matchMedia('(pointer:fine)').matches && !window.matchMedia('(prefers-reduced-motion:reduce)').matches){
  document.querySelectorAll('.btn').forEach(btn=>{
    btn.addEventListener('pointermove',e=>{
      const r=btn.getBoundingClientRect();
      const x=(e.clientX-r.left-r.width/2)/r.width;
      const y=(e.clientY-r.top-r.height/2)/r.height;
      btn.style.transform=`translate(${x*5}px,${y*4-5}px) scale(1.015)`;
    });
    btn.addEventListener('pointerleave',()=>btn.style.transform='');
  });
}
